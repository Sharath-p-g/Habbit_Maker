package com.example.habbitreminder;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

const form = document.getElementById("reminder-form");
const list = document.getElementById("reminder-list");
const reminders = JSON.parse(localStorage.getItem("reminders") || "[]");
const buzzer = new Audio("https://www.soundjay.com/button/beep-07.mp3"); // Buzzer sound URL

function speakMessage(text) {
  const synth = window.speechSynthesis;
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.volume = 1; // Max volume
  utterance.rate = 1;
  synth.speak(utterance);
}

function renderReminders() {
  list.innerHTML = '';
  reminders.forEach((reminder, index) => {
    const div = document.createElement('div');
    div.className = 'reminder-item';

    const reminderLink = document.createElement('a');
    reminderLink.href = `details.html?index=${index}`;
    reminderLink.textContent = `${reminder.date} ${reminder.time} - ${reminder.message}`;
    reminderLink.style.color = 'white';
    reminderLink.style.textDecoration = 'none';

    div.appendChild(reminderLink);

    const deleteButton = document.createElement('button');
    deleteButton.textContent = "Delete";
    deleteButton.onclick = () => {
      reminders.splice(index, 1);
      localStorage.setItem("reminders", JSON.stringify(reminders));
      renderReminders();
    };

    div.appendChild(deleteButton);
    list.appendChild(div);
  });
}

function checkReminders() {
  const now = new Date();
  const currentDate = now.toISOString().split('T')[0];
  const currentTime = now.toTimeString().slice(0, 5); // "HH:MM"

  reminders.forEach((reminder, index) => {
    if (reminder.date === currentDate && reminder.time === currentTime && !reminder.triggered) {
      // Mark as triggered to avoid repeat
      reminders[index].triggered = true;
      localStorage.setItem("reminders", JSON.stringify(reminders));

      buzzer.play(); // Play buzzer sound
      speakMessage(reminder.message); // Speak the reminder message
      alert("Reminder: " + reminder.message); // Show alert message
    }
  });
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const message = document.getElementById("habit").value;
  const time = document.getElementById("time").value;
  const date = new Date().toISOString().split('T')[0]; // today's date

  const reminder = {
    message,
    time,
    date,
    triggered: false
  };

  reminders.push(reminder);
  localStorage.setItem("reminders", JSON.stringify(reminders));
  renderReminders();
  form.reset();
});

renderReminders();
setInterval(checkReminders, 1000); // Check every second
